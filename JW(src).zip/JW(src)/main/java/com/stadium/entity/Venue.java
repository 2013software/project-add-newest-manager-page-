package com.stadium.entity;

import lombok.Data;

@Data
public class Venue{
    int id;
    String venue_name;
    String time;
    String userid;
}
