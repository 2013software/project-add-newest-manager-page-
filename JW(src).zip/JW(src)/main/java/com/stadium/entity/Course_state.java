package com.stadium.entity;

import lombok.Data;

@Data
public class Course_state {
    int id;
    int courseid;
    int userid;
}
